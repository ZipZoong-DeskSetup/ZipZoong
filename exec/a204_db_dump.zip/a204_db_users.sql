-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: j10a204.p.ssafy.io    Database: a204_db
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` varchar(255) NOT NULL,
  `create_at` datetime(6) NOT NULL,
  `update_at` datetime(6) NOT NULL,
  `user_img` varchar(255) DEFAULT NULL,
  `user_is_deleted` bit(1) DEFAULT NULL,
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_role` enum('ROLE_USER') DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('1','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','썽원','ROLE_USER'),('10','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','이싸피','ROLE_USER'),('2','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','찌은','ROLE_USER'),('3','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','수현','ROLE_USER'),('4','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','집중','ROLE_USER'),('5','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','솬솬','ROLE_USER'),('6','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','츈식','ROLE_USER'),('7','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','라이언','ROLE_USER'),('8','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','망곰','ROLE_USER'),('9','2024-03-25 04:14:23.000000','2024-03-25 04:14:23.000000','',_binary '\0','호날두','ROLE_USER'),('google 101767725869539433246','2024-04-03 14:05:42.100582','2024-04-03 14:05:42.100582',NULL,_binary '\0','한잔해','ROLE_USER'),('google 102454102944571917849','2024-03-28 10:31:51.129724','2024-04-04 01:41:17.102123',NULL,_binary '\0','김싸피','ROLE_USER'),('google 102811383281363052920','2024-04-03 14:23:22.203714','2024-04-04 05:16:43.226058','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/profiles/5be0d03f-0d2b-4300-9c7b-fc6edf5c9680.png',_binary '\0','a12aa','ROLE_USER'),('google 104007127852196129623','2024-04-01 13:46:21.645791','2024-04-04 10:36:55.058214','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/profiles/9bb8879f-27bb-42bf-bb8f-19075e3bc825.jpeg',_binary '\0',' 문땅훈','ROLE_USER'),('google 109456610994809877295','2024-03-30 17:48:15.144897','2024-03-30 17:48:15.144897',NULL,_binary '\0','홀란두','ROLE_USER'),('google 115954812700900524633','2024-04-03 11:35:04.327807','2024-04-04 11:16:17.570761',NULL,_binary '\0',' 이재용','ROLE_USER'),('google 115983189628154561555','2024-03-25 14:05:00.384374','2024-04-04 10:44:38.172026','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/profiles/7eb3b977-4cbe-4a64-bbc5-1207d894f0e6.png',_binary '\0','맨시티짱','ROLE_USER'),('google 117067319482558631880','2024-04-03 21:50:30.600612','2024-04-04 01:52:55.512600','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/profiles/70729f4a-6a0a-4c93-a244-1bce19faba55.png',_binary '\0',' hj_te2','ROLE_USER'),('google 117737780224757024289','2024-04-01 16:16:36.947131','2024-04-01 16:16:36.947131',NULL,_binary '\0','삼성가자','ROLE_USER'),('kakao 3394017182','2024-03-28 10:47:16.874848','2024-04-04 01:42:22.290339',NULL,_binary '\0','박싸피','ROLE_USER'),('kakao 3421236276','2024-04-04 10:51:38.319541','2024-04-04 10:53:04.224740','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/profiles/08e5cceb-7207-4b1d-991a-c96a7049f2d9.PNG',_binary '\0','망그러지다만곰','ROLE_USER'),('naver 0PtDp_M1lqV6TDX7dSaMRJZIQ0B6nlZMLBrIv44UwU4','2024-03-28 10:47:24.696337','2024-03-28 10:47:24.696337',NULL,_binary '\0','한잔해','ROLE_USER');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 11:31:36
