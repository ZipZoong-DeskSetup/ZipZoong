-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: j10a204.p.ssafy.io    Database: a204_db
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey` (
  `survey_id` int NOT NULL AUTO_INCREMENT,
  `keyboard_color` enum('BLACK','WHITE','COLOR','OTHERS','NONE') NOT NULL,
  `keyboard_connection` enum('WIRE','WIRELESS','BOTH') NOT NULL,
  `keyboard_health` bit(1) NOT NULL,
  `keyboard_layout` int NOT NULL,
  `keyboard_price` int NOT NULL,
  `keyboard_sound` enum('RED','BLACK','BROWN','BLUE') NOT NULL,
  `keyboard_type` enum('MEMBRANE','PANTOGRAPH','MECHANICAL') NOT NULL,
  `keyboard_usage` int NOT NULL,
  `monitor_count` int NOT NULL,
  `monitor_panel` enum('FLAT','CURVED') NOT NULL,
  `monitor_price` int NOT NULL,
  `monitor_ratio` int DEFAULT NULL,
  `monitor_size` int DEFAULT NULL,
  `monitor_usage` int NOT NULL,
  `mouse_color` enum('BLACK','WHITE','COLOR','OTHERS','NONE') NOT NULL,
  `mouse_connection` enum('WIRE','WIRELESS','BOTH') NOT NULL,
  `mouse_health` bit(1) NOT NULL,
  `mouse_price` int NOT NULL,
  `mouse_sound` bit(1) DEFAULT NULL,
  `mouse_usage` int NOT NULL,
  `survey_detail` enum('SIMPLE','DETAIL') NOT NULL,
  `total_price` int NOT NULL,
  `user_id` varchar(50) NOT NULL,
  PRIMARY KEY (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (10,'BLACK','WIRE',_binary '',1,90,'RED','MEMBRANE',1,1,'FLAT',180,1,1,1,'BLACK','WIRE',_binary '',30,_binary '',1,'SIMPLE',300,'google 115954812700900524633'),(26,'BLACK','BOTH',_binary '\0',4,30,'RED','MECHANICAL',2,1,'FLAT',60,1,1,2,'BLACK','BOTH',_binary '\0',10,_binary '',2,'DETAIL',100,'google 101767725869539433246'),(33,'COLOR','BOTH',_binary '',4,15,'RED','MECHANICAL',4,1,'FLAT',30,1,4,4,'COLOR','BOTH',_binary '',5,_binary '',4,'SIMPLE',50,'google 115983189628154561555'),(34,'WHITE','BOTH',_binary '\0',2,3,'BROWN','MECHANICAL',4,1,'CURVED',6,2,2,4,'WHITE','BOTH',_binary '\0',1,_binary '',4,'DETAIL',10,'google 104007127852196129623'),(35,'COLOR','BOTH',_binary '\0',2,79,'BROWN','MECHANICAL',4,1,'CURVED',158,4,8,4,'COLOR','BOTH',_binary '\0',26,_binary '',4,'DETAIL',264,'kakao 3421236276'),(36,'WHITE','BOTH',_binary '\0',4,94,'RED','MECHANICAL',2,1,'FLAT',188,1,4,2,'WHITE','BOTH',_binary '\0',31,_binary '',2,'SIMPLE',313,'google 102811383281363052920'),(37,'WHITE','BOTH',_binary '\0',1,14,'BROWN','MECHANICAL',4,1,'CURVED',27,4,8,4,'WHITE','BOTH',_binary '\0',5,_binary '',4,'DETAIL',45,'google 102454102944571917849');
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 11:31:35
