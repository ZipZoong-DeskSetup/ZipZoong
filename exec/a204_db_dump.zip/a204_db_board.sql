-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: j10a204.p.ssafy.io    Database: a204_db
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` int NOT NULL AUTO_INCREMENT,
  `create_at` datetime(6) NOT NULL,
  `update_at` datetime(6) NOT NULL,
  `board_content` text,
  `board_hit` int DEFAULT NULL,
  `board_is_deleted` bit(1) DEFAULT NULL,
  `board_is_draft` bit(1) DEFAULT NULL,
  `board_title` varchar(200) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `board_thumbnail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`board_id`),
  KEY `FK5vlh90qyii65ixwsbnafd55ud` (`user_id`),
  CONSTRAINT `FK5vlh90qyii65ixwsbnafd55ud` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'2024-03-24 15:28:05.000000','2024-03-24 15:28:05.000000','디자이너겸 프론트엔드 개발자의 모던한 데스크 셋업',71,_binary '\0',_binary '\0','디자이너겸 프론트엔드 개발자의 모던한 데스크 셋업','google 115983189628154561555','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post1.jfif'),(2,'2024-03-26 09:32:05.000000','2024-03-26 09:32:05.000000','은은한 조명이 감싸는 화이트 데스크 셋업',41,_binary '\0',_binary '\0','은은한 조명이 감싸는 화이트 데스크 셋업','google 102454102944571917849','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post6.jfif'),(3,'2024-03-28 01:28:05.000000','2024-03-28 01:28:05.000000','업무효율 3000만큼 높여주는 장비들',47,_binary '\0',_binary '\0','업무효율 3000만큼 높여주는 장비들','google 102811383281363052920','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post3.png'),(4,'2024-03-29 10:30:04.886438','2024-03-29 10:30:04.886438','미래 벤츠 오너의 웜톤 데스크 셋업',12,_binary '\0',NULL,'미래 벤츠 오너의 웜톤 데스크 셋업','google 104007127852196129623','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post4.jfif'),(5,'2024-03-29 13:20:53.711397','2024-03-29 13:20:53.711397','프리랜서의 올블랙 데스크 셋업',16,_binary '\0',NULL,'프리랜서의 올블랙 데스크 셋업','google 109456610994809877295','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post5.jfif'),(6,'2024-03-29 14:29:39.926774','2024-03-29 14:29:39.926774','병아리 웹개발자의 데스크',18,_binary '\0',NULL,'병아리 웹개발자의 데스크','kakao 3394017182','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post2.png'),(7,'2024-03-29 14:35:39.926774','2024-03-29 14:35:39.926774','2년차 S/W 연구원의 데스크 셋업',13,_binary '\0',NULL,'2년차 S/W 연구원의 데스크 셋업','kakao 3421236276','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post7.jfif'),(8,'2024-03-29 18:11:39.926774','2024-03-29 18:11:39.926774','스타트업 플러터 개발자의 데스크 셋업',13,_binary '\0',NULL,'스타트업 플러터 개발자의 데스크 셋업','google 101767725869539433246','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post8.jfif'),(9,'2024-03-29 19:53:39.926774','2024-03-29 19:53:39.926774','바깥뷰가 멋진 자바 개발자의 데스크',3,_binary '\0',NULL,'바깥뷰가 멋진 자바 개발자의 데스크','google 117737780224757024289','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post9.png'),(10,'2024-03-30 11:31:39.926774','2024-03-30 11:31:39.926774','귀여운 소품님들과 함께 코딩하는 Typescript 개발자',24,_binary '\0',NULL,'귀여운 소품님들과 함께 코딩하는 Typescript 개발자','google 117067319482558631880','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post10.jfif'),(11,'2024-03-30 20:53:39.926774','2024-03-30 20:53:39.926774','바깥뷰가 멋진 자바 개발자의 데스크',3,_binary '\0',NULL,'바깥뷰가 멋진 자바 개발자의 데스크','naver 0PtDp_M1lqV6TDX7dSaMRJZIQ0B6nlZMLBrIv44UwU4','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post11.png'),(12,'2024-03-31 11:31:39.926774','2024-03-31 11:31:39.926774','모니터와 램은 많을수록 좋죠. 의자 추천 받습니다~!',24,_binary '\0',NULL,'모니터와 램은 많을수록 좋죠. 의자 추천 받습니다~!','1','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post12.jfif'),(13,'2024-04-01 19:53:39.926774','2024-04-01 19:53:39.926774','개발공부에 저 집중하고 싶은 고등학생의 데스크 셋업',3,_binary '\0',NULL,'개발공부에 저 집중하고 싶은 고등학생의 데스크 셋업','2','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post13.jfif'),(14,'2024-04-01 11:31:39.926774','2024-04-01 11:31:39.926774','교내 커뮤니티에서 사이드 프로젝트를 하고 있는 풀스택 개발자',25,_binary '\0',NULL,'교내 커뮤니티에서 사이드 프로젝트를 하고 있는 풀스택 개발자','3','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post14.jfif'),(15,'2024-04-02 19:53:39.926774','2024-04-02 19:53:39.926774','퇴사 후 개발자로 진로변경을 꿈구는 이직 준비생의 데스크 셋업',3,_binary '\0',NULL,'퇴사 후 개발자로 진로변경을 꿈구는 이직 준비생의 데스크 셋업','4','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post15.png'),(16,'2024-04-02 11:31:39.926774','2024-04-02 11:31:39.926774','프론트엔드 개발자의 블랙&화이트 데스크 셋업',24,_binary '\0',NULL,'프론트엔드 개발자의 블랙&화이트 데스크 셋업','5','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post16.png'),(17,'2024-04-03 19:53:39.926774','2024-04-03 19:53:39.926774','풀스택 프리랜서 개발자의 취향 듬뿍 데스크 셋업',3,_binary '\0',NULL,'풀스택 프리랜서 개발자의 취향 듬뿍 데스크 셋업','6','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post17.png'),(18,'2024-04-03 11:31:39.926774','2024-04-03 11:31:39.926774','손목 건강 절대 지켜! 키보드 추천',26,_binary '\0',NULL,'손목 건강 절대 지켜! 키보드 추천','7','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post18.jfif'),(19,'2024-04-03 19:53:39.926774','2024-04-03 19:53:39.926774','딱 필요한 것 위주로 실속있는 데스크 셋업',4,_binary '\0',NULL,'딱 필요한 것 위주로 실속있는 데스크 셋업','8','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post19.png'),(20,'2024-04-03 11:31:39.926774','2024-04-03 11:31:39.926774','심플하게 딱 하나로 승부합니다. 장비 추천 받음',25,_binary '\0',NULL,'심플하게 딱 하나로 승부합니다. 장비 추천 받음','9','https://zipzoong-bucket.s3.ap-northeast-2.amazonaws.com/posts/post20.jfif');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 11:31:38
